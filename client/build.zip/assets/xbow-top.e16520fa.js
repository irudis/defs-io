var o="/assets/xbow-top.221746d2.png";export{o as default};
