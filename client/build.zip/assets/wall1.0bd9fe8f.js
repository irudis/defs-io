var a="/assets/wall1.7e900a93.png";export{a as default};
