var a="/assets/cannon-base6.e17101cd.png";export{a as default};
