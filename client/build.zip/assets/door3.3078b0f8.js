var o="/assets/door3.088cbb64.png";export{o as default};
