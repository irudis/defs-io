var a="/assets/xbow-base0.a39ef6a8.png";export{a as default};
