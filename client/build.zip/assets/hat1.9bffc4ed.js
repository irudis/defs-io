var a="/assets/hat1.fbbd5dfb.png";export{a as default};
