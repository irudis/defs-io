var e="/assets/gold_miner-base2.44b72446.png";export{e as default};
