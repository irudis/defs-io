var a="/assets/hands1.f898f4a0.png";export{a as default};
