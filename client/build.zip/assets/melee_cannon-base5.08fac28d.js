var e="/assets/melee_cannon-base5.1e7cddb2.png";export{e as default};
