var e="/assets/melee_cannon-base6.c4c5bedf.png";export{e as default};
