var s="/assets/style6.96d7f022.png";export{s as default};
