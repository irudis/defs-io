var a="/assets/xbow-base4.d3432fe3.png";export{a as default};
