var e="/assets/tree.e40d6dd0.png";export{e as default};
