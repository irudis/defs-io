var a="/assets/hands3.f6bfcdab.png";export{a as default};
