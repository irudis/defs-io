var e="/assets/stone.cfc740be.png";export{e as default};
