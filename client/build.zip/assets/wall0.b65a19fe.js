var a="/assets/wall0.c3d7269f.png";export{a as default};
