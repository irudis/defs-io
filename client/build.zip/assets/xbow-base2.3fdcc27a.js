var a="/assets/xbow-base2.627d1e98.png";export{a as default};
