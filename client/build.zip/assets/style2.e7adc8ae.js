var s="/assets/style2.ca0f4f04.png";export{s as default};
