var d="/assets/door5.3ae9d0dd.png";export{d as default};
