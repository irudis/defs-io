var s="/assets/style3.c2766d9b.png";export{s as default};
