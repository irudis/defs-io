var a="/assets/cannon-base4.ebbceb55.png";export{a as default};
