var a="/assets/base6.cbf90e4f.png";export{a as default};
