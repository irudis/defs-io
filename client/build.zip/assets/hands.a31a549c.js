var a="/assets/hands.4e135b10.png";export{a as default};
