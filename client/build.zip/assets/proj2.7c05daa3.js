var a="/assets/proj2.357a494f.png";export{a as default};
