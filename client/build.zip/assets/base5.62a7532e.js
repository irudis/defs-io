var a="/assets/base5.8f4bc3b2.png";export{a as default};
