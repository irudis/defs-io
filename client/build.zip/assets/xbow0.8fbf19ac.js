var a="/assets/xbow0.658c8812.png";export{a as default};
