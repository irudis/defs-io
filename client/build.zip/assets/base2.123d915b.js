var a="/assets/base2.2e149e3a.png";export{a as default};
