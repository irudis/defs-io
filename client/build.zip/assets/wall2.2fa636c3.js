var a="/assets/wall2.d7cac0b6.png";export{a as default};
