var s="/assets/hat-boss.685efde4.png";export{s as default};
