var e="/assets/melee_cannon0.e2f52e8f.png";export{e as default};
