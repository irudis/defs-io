var a="/assets/particle-poop.14baa026.png";export{a as default};
