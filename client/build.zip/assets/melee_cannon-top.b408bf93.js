var e="/assets/melee_cannon-top.35d831ec.png";export{e as default};
