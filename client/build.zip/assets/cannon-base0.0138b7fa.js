var a="/assets/cannon-base0.fc347d82.png";export{a as default};
