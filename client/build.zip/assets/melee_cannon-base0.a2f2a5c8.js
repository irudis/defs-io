var e="/assets/melee_cannon-base0.a290647f.png";export{e as default};
