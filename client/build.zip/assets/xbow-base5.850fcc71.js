var a="/assets/xbow-base5.ed35f597.png";export{a as default};
