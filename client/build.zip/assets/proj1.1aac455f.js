var e="/assets/proj1.e64b315e.png";export{e as default};
