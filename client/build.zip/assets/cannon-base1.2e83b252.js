var a="/assets/cannon-base1.a45a2cda.png";export{a as default};
