var e="/assets/melee_cannon-base3.9432bcad.png";export{e as default};
