var a="/assets/cannon-base3.be957785.png";export{a as default};
