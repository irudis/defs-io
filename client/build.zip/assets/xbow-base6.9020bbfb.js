var a="/assets/xbow-base6.132a5532.png";export{a as default};
