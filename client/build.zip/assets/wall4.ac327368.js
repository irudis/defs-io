var a="/assets/wall4.af22e391.png";export{a as default};
