var e="/assets/gold_miner-base5.3f14d3f7.png";export{e as default};
