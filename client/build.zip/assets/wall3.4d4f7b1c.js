var a="/assets/wall3.5c8dd937.png";export{a as default};
