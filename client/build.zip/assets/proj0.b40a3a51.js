var a="/assets/proj0.8ab6359a.png";export{a as default};
