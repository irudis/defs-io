var a="/assets/door1.4e3563ae.png";export{a as default};
