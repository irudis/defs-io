var a="/assets/hat2.3dc994e2.png";export{a as default};
