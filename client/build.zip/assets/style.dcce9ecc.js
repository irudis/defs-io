var s="/assets/style.907d1689.png";export{s as default};
