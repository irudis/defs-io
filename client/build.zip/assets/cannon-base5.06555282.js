var a="/assets/cannon-base5.d18dc8d9.png";export{a as default};
