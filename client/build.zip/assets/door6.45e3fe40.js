var o="/assets/door6.be8689c8.png";export{o as default};
