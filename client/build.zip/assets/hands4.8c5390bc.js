var a="/assets/hands4.e3565482.png";export{a as default};
