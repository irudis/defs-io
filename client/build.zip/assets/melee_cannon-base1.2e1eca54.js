var e="/assets/melee_cannon-base1.22480e73.png";export{e as default};
