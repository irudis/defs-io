var e="/assets/gold_miner-base0.fb251c78.png";export{e as default};
