var e="/assets/gold_miner-base4.cbc85660.png";export{e as default};
