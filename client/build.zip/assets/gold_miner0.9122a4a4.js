var e="/assets/gold_miner0.c8be9679.png";export{e as default};
