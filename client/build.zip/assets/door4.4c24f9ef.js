var a="/assets/door4.c5ff3dea.png";export{a as default};
