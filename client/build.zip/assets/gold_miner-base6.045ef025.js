var e="/assets/gold_miner-base6.f393926e.png";export{e as default};
