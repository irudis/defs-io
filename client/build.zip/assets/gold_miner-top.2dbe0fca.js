var e="/assets/gold_miner-top.9c4d1b8b.png";export{e as default};
