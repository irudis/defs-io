var s="/assets/style1.5b16cb27.png";export{s as default};
