var e="/assets/melee_cannon-base4.6e1141b7.png";export{e as default};
