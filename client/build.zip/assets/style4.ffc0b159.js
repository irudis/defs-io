var a="/assets/style4.6bceb2aa.png";export{a as default};
