var s="/assets/style5.54940548.png";export{s as default};
