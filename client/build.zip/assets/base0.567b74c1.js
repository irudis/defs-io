var e="/assets/base0.53224bee.png";export{e as default};
