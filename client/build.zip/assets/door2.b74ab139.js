var o="/assets/door2.5bfc991c.png";export{o as default};
