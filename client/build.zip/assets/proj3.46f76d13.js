var a="/assets/proj3.700efc56.png";export{a as default};
