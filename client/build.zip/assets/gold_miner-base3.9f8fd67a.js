var e="/assets/gold_miner-base3.cd6f8c20.png";export{e as default};
