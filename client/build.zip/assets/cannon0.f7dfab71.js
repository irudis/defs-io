var n="/assets/cannon0.407979d5.png";export{n as default};
