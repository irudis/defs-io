var a="/assets/xbow-base3.c14bc757.png";export{a as default};
