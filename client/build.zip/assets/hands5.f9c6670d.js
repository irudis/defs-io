var a="/assets/hands5.32deac9f.png";export{a as default};
