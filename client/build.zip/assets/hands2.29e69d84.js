var a="/assets/hands2.7835b0fc.png";export{a as default};
