var a="/assets/xbow-base1.7e56c3a9.png";export{a as default};
