var n="/assets/cannon-top.c1546416.png";export{n as default};
