var e="/assets/gold_miner-base1.e94c27d6.png";export{e as default};
