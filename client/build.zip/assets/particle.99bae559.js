var a="/assets/particle.5e3688f4.png";export{a as default};
