var a="/assets/hands6.5ae9f4ff.png";export{a as default};
