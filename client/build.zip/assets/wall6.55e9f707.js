var a="/assets/wall6.62047ee0.png";export{a as default};
