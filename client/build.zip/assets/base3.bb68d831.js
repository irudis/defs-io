var a="/assets/base3.ae30df14.png";export{a as default};
