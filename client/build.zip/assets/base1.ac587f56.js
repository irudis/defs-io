var a="/assets/base1.2e3a34e1.png";export{a as default};
