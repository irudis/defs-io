var e="/assets/melee_cannon-base2.c9086676.png";export{e as default};
