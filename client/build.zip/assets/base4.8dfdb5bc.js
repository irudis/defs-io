var a="/assets/base4.6c86f118.png";export{a as default};
