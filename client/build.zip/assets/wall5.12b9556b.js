var a="/assets/wall5.c888a265.png";export{a as default};
