var o="/assets/door0.b1f3903b.png";export{o as default};
