var a="/assets/cannon-base2.9a1be87b.png";export{a as default};
